THIS TEXTUREPACK MADE BY: Blizard72

This is a small but complex retexture of the minecraft default textures.
This texture pack does not require any mods to run.

I made this texture pack because I felt the default textures in minecraft did not make sense,
or were too strenious on the players eyes.
What this texture pack offers is a better utility, usefullness, look, and feel of minecraft,
without needing to modify any of the original minecraft files.

common textures are simplified as to not feel repeatitive,
softened to reduce the contrasting strain on the user,
and smoothed to help with removing the moire effect at greater distances.


Any comments or errors please email me at:
  blizard72@gmail.com
